# Control what gets imported when users do from mathshapes import *
# __all__ = ["mathoperations", "shapes3d", "shapes"]
