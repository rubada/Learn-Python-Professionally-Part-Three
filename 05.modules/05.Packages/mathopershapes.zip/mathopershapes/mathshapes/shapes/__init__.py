# Control what gets imported when users do from mathshapes import *
# __all__ = ["circle", "rectange", "triangle"]
