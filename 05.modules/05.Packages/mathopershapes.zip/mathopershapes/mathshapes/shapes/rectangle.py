
def area(length, width):
    return length * width


def perimeter(length, width):
    return 2 * (length + width)


if __name__ == "__main__":
    print(f"The Rectangel Area = {area(2, 4)}")
    print(f"The Rectangel Perimeter = {perimeter(2, 4)}")
