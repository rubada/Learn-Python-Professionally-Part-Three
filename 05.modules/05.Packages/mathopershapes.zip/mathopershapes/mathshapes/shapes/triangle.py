
def area(length, width):
    return 0.5 * length * width


def perimeter(side1, side2, side3):
    return side1 + side2 + side3


if __name__ == "__main__":
    print(f"The Triangle Area = {area(6, 4)}")
    print(f"The Triangle Perimeter = {perimeter(7, 4, 5)}")
