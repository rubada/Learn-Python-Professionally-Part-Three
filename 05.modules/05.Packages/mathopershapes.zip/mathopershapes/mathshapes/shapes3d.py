import math


class Cylinder():

    @staticmethod
    def total_surface_area(radius, height):
        circular_base_area = 2 * math.pi * math.pow(radius, 2)
        surface_area = 2 * math.pi * radius * height
        cylinder_area = circular_base_area + surface_area
        return cylinder_area

    @staticmethod
    def volume(radius, height):
        return height * math.pi * math.pow(radius, 2)

    @staticmethod
    def diameter(radius):
        return 2 * radius

    @staticmethod
    def diagonal():
        return "A cylinder doesn't have a diagonal."


class RectanglePrism():

    @staticmethod
    def total_surface_area(width, length, height):
        return 2 * (width * length + width * height
                    + length * height)

    @staticmethod
    def volume(width, length, height):
        return length * width * height

    @staticmethod
    def diameter():
        return "Rectangle Prism doesn't have a diameter."

    @staticmethod
    def diagonal(width, length, height):
        lwh_square = (math.pow(length, 2) + math.pow(width, 2) +
                      math.pow(height, 2))
        diagonal = math.sqrt(lwh_square)
        return diagonal


def main():
    print(Cylinder.diameter(2))
    print(Cylinder.total_surface_area(2, 5))
    print(Cylinder.volume(2, 5))
    print(Cylinder.diagonal())

    print(RectanglePrism.diagonal(3, 4, 7))
    print(RectanglePrism.total_surface_area(3, 4, 7))
    print(RectanglePrism.volume(3, 4, 7))
    print(RectanglePrism.diameter())


if __name__ == "__main__":
    main()
