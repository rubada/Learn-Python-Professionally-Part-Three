MathShapes is about mathematical operations and shapes areas and perimeters", 
you can calculate the circle, rectangle, triangle areas, and perimeters just by importing
the required modules from this package.

Check the below guide for packaging
https://packaging.python.org/en/latest/#python-packaging-user-guide

For more information on how to create an installable Package:
https://packaging.python.org/en/latest/tutorials/packaging-projects/

To learn more about source distribution and wheel check the below site:
https://packaging.python.org/en/latest/tutorials/installing-packages/#source-distributions-vs-wheels

To learn more about pyproject.toml
https://packaging.python.org/en/latest/tutorials/packaging-projects/#choosing-a-build-backend

Twine is a utility for publishing Python packages on PyPI.
https://pypi.org/project/twine/

To create a source distribution, a "<name>.tar.gz" file:
python setup.py sdist

To create a wheel:
python setup.py bdist_wheel

To create both, a source distribution and a wheel:
python setup.py sdist bdist_wheel

To install the package locally, create a new directory where you want to install the package, then add the "<name>.tar.gz" and "<name>.wh" files in it.
Then Type the following in your terminal:
python -m pip install <package-name> --no-index --find-links=<directory-name>

For example, if your directory name is <packages> and your package name is <mathshapes>, type the following in your terminal:
python -m pip install mathshapes --no-index --find-links=packages

To uninstall it
python -m pip uninstall mathshapes