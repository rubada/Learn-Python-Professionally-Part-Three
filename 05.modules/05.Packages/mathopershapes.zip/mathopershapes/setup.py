# First install the "setuptools" module
import setuptools
import os

req_path = os.path.join(os.path.dirname(__file__), "requirements.txt")
readme_path = os.path.join(os.path.dirname(__file__), "readme.md")

with open(req_path) as file:
    requirements = file.readlines()

with open(readme_path) as file:
    readme = file.read()

setuptools.setup(
    name="mathshapes",
    version=1.0,
    author="Ruba Dabbas",
    author_email="ruba@example.com",
    description=(
        "This Package is about mathmatical operations and calculating areas\
and perimeters for different shapes"),
    # Detailed description in the README file
    long_description=readme,
    url="https://github.com/rubada/mathshapes",
    # Automatically find packages in the directory
    packages=setuptools.find_packages(),
    # install_requires, specifies what the project minimally needs (packages)
    # to run correctly.
    install_requires=requirements,  # Pass requirements list here
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        # OSI Approved refers to licenses that have been approved by the Open
        # Source Initiative (OSI).
        "Operating System :: OS Independent",
    ],
    license="MIT License",
    python_requires='>=3.6',  # Specify compatible Python versions
)
